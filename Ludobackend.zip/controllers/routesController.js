const db = require("./../db/connection.js");
let nanoid;
import('nanoid').then(module => {
  nanoid = module.nanoid;
});

exports.joinOrCreateGame = async (req, res, next) => {
  const playersData = req.body;

  if (!Array.isArray(playersData) || playersData.length === 0) {
    return res.status(400).json({ message: 'Invalid or empty players array.' });
  }

  // Validate each player
 if (!Array.isArray(playersData) || playersData.length === 0) {
  return res.status(400).json({ message: 'Players data is required.' });
}

// Extract the base reference from the first player
const base = playersData[0];

// Ensure all required fields are present in the first player
const requiredFields = ['matchTime', 'matchType', 'pricePool', 'user_id', 'name'];
for (const field of requiredFields) {
  if (!base[field]) {
    return res.status(400).json({ message: `Missing field "${field}" in the first player.` });
  }
}

// MatchType to expected player count
const matchTypeToCount = {
  two: 2,
  three: 3,
  four: 4
};

const expectedCount = matchTypeToCount[base.matchType.toLowerCase()];
if (!expectedCount) {
  return res.status(400).json({ message: `Invalid matchType: "${base.matchType}"` });
}

if (playersData.length !== expectedCount) {
  return res.status(400).json({
    message: `Expected ${expectedCount} players for matchType "${base.matchType}", but got ${playersData.length}.`
  });
}

// Now validate each player
for (const player of playersData) {
  for (const field of requiredFields) {
    if (!player[field]) {
      return res.status(400).json({
        message: `Missing field "${field}" in one of the players.`,
        invalidPlayer: player
      });
    }
  }

  if (
    player.matchTime !== base.matchTime ||
    player.matchType !== base.matchType ||
    player.pricePool !== base.pricePool
  ) {
    return res.status(400).json({
      message: 'All players must have the same matchTime, matchType, and pricePool.',
      invalidPlayer: player
    });
  }
}

  const { matchTime, matchType, pricePool } = playersData[0]; // shared values
  const connection = await db.pool.getConnection();

  try {
    await connection.beginTransaction();

    // 1. Find existing match with available space and same matchType & matchTime
    const [existingMatches] = await connection.execute(
      `SELECT match_id FROM matches 
       WHERE match_type = ? AND match_status = 'waiting' AND match_time = ?`,
      [matchType, matchTime]
    );

    let matchIdToUse = null;
    const maxPlayers = matchType === 'two' ? 2 : matchType === 'three' ? 3 : 4;


    for (const row of existingMatches) {
      const [players] = await connection.execute(
        `SELECT COUNT(*) as count FROM players WHERE match_id = ?`,
        [row.match_id]
      );

      const playerCount = players[0].count;

      if (playerCount + playersData.length <= maxPlayers) {
        matchIdToUse = row.match_id;
        break;
      }
    }

    // 2. If no match found → Create new match
    if (!matchIdToUse) {
      matchIdToUse = `${new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 14)}-${nanoid(5)}`;

      await connection.execute(
        `INSERT INTO matches (match_id, match_time, match_type, price_pool)
         VALUES (?, ?, ?, ?)`,
        [matchIdToUse, matchTime, matchType, pricePool]
      );
    }

    // 3. Get colors already used
    const [usedColors] = await connection.execute(
      `SELECT color FROM players WHERE match_id = ?`,
      [matchIdToUse]
    );
    const used = usedColors.map(p => p.color);

    let allColors = ['red', 'blue', 'green', 'yellow'];

    // 3.1 Consistent color pairs for "two" matches
    if (matchType === 'two') {
      const duoColorPairs = [['green', 'blue'], ['red', 'yellow']];
      const hash = Array.from(matchIdToUse).reduce((acc, char) => acc + char.charCodeAt(0), 0);
      const index = hash % duoColorPairs.length;
      allColors = duoColorPairs[index];
    }

    let availableColors = allColors.filter(c => !used.includes(c));

    if (availableColors.length < playersData.length) {
      return res.status(400).json({ message: 'Not enough spots/colors available in the match.' });
    }

    const insertedPlayers = [];

    for (const player of playersData) {
      const { user_id, name } = player;

      // 3.5 Check if player already exists
      const [existingPlayer] = await connection.execute(
        `SELECT 1 FROM players WHERE match_id = ? AND user_id = ?`,
        [matchIdToUse, user_id]
      );

      if (existingPlayer.length > 0) {
        return res.status(400).json({
          message: 'One or more users already joined this match.',
          user_id
        });
      }

      const color = availableColors.shift(); // Assign first available color

      // 4. Insert player
      await connection.execute(
        `INSERT INTO players (match_id, user_id, name, color, score, winner)
         VALUES (?, ?, ?, ?, 0, NULL)`,
        [matchIdToUse, user_id, name, color]
      );

      insertedPlayers.push({ user_id, name, assignedColor: color });
    }

    await connection.commit();
    res.status(201).json({
      message: 'Players joined successfully.',
      matchId: matchIdToUse,
      players: insertedPlayers
    });

  } catch (err) {
    await connection.rollback();
    next(err);
  } finally {
    connection.release();
  }
};





// updation of gamestatus
exports.updateMatchStatus = async (req, res, next) => {
  const { matchId } = req.params;
  const { matchStatus } = req.body;

  // Validate status
  const valid = ['waiting', 'started', 'completed'];
  if (!valid.includes(matchStatus)) {
    return res.status(400).json({ error: 'Invalid matchStatus' });
  }

  try {
    const [result] = await db.execute(
      `UPDATE games SET matchStatus = ? WHERE matchId = ?`,
      [matchStatus, matchId]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Game not found' });
    }
    res.sendStatus(204);
  } catch (err) {
    next(err);
  }
};



exports.getPlayerMatches = async (req, res, next) => {
  const { user_id } = req.params;

  if (!user_id) {
    return res.status(400).json({ message: 'Missing user_id.' });
  }

  const connection = await db.pool.getConnection();
  try {
    // Get all matches user is part of
    const [playerMatches] = await connection.execute(
      `SELECT p.*, m.match_time, m.match_type, m.price_pool, m.match_status
       FROM players p
       JOIN matches m ON p.match_id = m.match_id
       WHERE p.user_id = ?`,
      [user_id]
    );

    res.status(200).json({
      totalMatches: playerMatches.length,
      matches: playerMatches
    });

  } catch (err) {
    next(err);
  } finally {
    connection.release();
  }
};



exports.getMatchById = async (req, res, next) => {
  const { match_id } = req.params;

  if (!match_id) {
    return res.status(400).json({ message: 'Missing match_id.' });
  }

  const connection = await db.pool.getConnection();
  try {
    // Get match info
    const [matchRows] = await connection.execute(
      `SELECT * FROM matches WHERE match_id = ?`,
      [match_id]
    );

    if (matchRows.length === 0) {
      return res.status(404).json({ message: 'Match not found.' });
    }

    const match = matchRows[0];

    // Get all players in this match
    const [players] = await connection.execute(
      `SELECT * FROM players WHERE match_id = ?`,
      [match_id]
    );

    res.status(200).json({
      match,
      players
    });

  } catch (err) {
    next(err);
  } finally {
    connection.release();
  }
};
