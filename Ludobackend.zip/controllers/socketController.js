const db = require("./../db/connection.js");

const DISCONNECT_TIMEOUT = 3;

// Robust room initialization function
function initializeRoom(roomId, existingRoom = null) {
  if (existingRoom) {
    return {
      players: existingRoom.players || {},
      match: existingRoom.match || {},
      turnOrder: existingRoom.turnOrder || [],
      currentTurnIdx: existingRoom.currentTurnIdx || 0,
      timerInterval: existingRoom.timerInterval || null,
      started: existingRoom.started || false,
      turnTimer: existingRoom.turnTimer || null,
      externalTimer: existingRoom.externalTimer || 5,
      disconnectedPlayers: existingRoom.disconnectedPlayers || {},
    };
  }

  return {
    players: {},
    match: {},
    turnOrder: [],
    currentTurnIdx: 0,
    timerInterval: null,
    started: false,
    turnTimer: null,
    externalTimer: 5,
    disconnectedPlayers: {},
  };
}

async function checkRoomStatus(roomId) {
  try {
    if (!roomId) return { exists: false, status: null };
    
    const [rows] = await db.pool.query(
      "SELECT match_id, match_status FROM matches WHERE match_id = ? LIMIT 1",
      [roomId]
    );
    
    if (rows.length === 0) {
      // console.log("Room does not exist:", roomId);
      return { exists: false, status: null };
    }
    
    const status = rows[0].match_status;
    // console.log("Room check:", roomId, "exists:", true, "status:", status);
    return { exists: true, status: status };
    
  } catch (error) {
    console.error("Database error in checkRoomStatus:", error);
    return { exists: false, status: null };
  }
}

/**
 * Main socket.io handler function
 */
module.exports = function (io) {
  io.use(async (socket, next) => {
    try {
      const { roomId, user_id } = socket.handshake.auth || {};
      if (!roomId || !user_id) {
        return next(new Error("roomId and user_id required"));
      }

      // Check room existence and status separately
      const { exists, status } = await checkRoomStatus(roomId);
      
      if (!exists) {
        return next(new Error("room not found"));
      }
      
      if (status !== "waiting") {
        return next(new Error(`match is ${status} - connection not allowed`));
      }

      // Check if user is registered for this match
      const [rows] = await db.pool.query(
        "SELECT 1 FROM players WHERE match_id=? AND user_id=? LIMIT 1",
        [roomId, user_id]
      );
      if (rows.length === 0) {
        return next(new Error("user not registered for this match"));
      }

      socket.roomId = roomId;
      socket.user_id = user_id;
      next();
      
    } catch (error) {
      console.error("Middleware error:", error);
      next(new Error("connection authentication failed"));
    }
  });

  // Use a more robust rooms object initialization
  const rooms = {};
  const PATH_LENGTH = 57;
  const TURN_TIMEOUT = 12000;

  io.on("connection", (socket) => {
    // console.log(`Socket connected: ${socket.id}`);

    function broadcastRoom(roomId) {
      if (!rooms[roomId]) return;
      // console.log("Broadcasting Room State:", rooms[roomId]);
      io.to(roomId).emit("roomUpdated", rooms[roomId]);
    }

    /**
     * 1. CREATE ROOM
     */
    socket.on("createRoom", async (roomId) => {
      try {
        const connection = await db.pool.getConnection();

        // console.log("Received createRoom with roomId:", roomId, typeof roomId);
        try {
          const exists = await checkRoomStatus(roomId);

          if (!exists) {
            socket.emit("roomNotFound", { error: "Room does not exist in DB" });
            return;
          }
          const [matchRows] = await connection.execute(
            `SELECT * FROM matches WHERE match_id = ?`,
            [roomId]
          );
          if (matchRows[0].match_status !== "waiting") {
            return socket.emit(
              "error",
              "Match is already started or completed"
            );
          }

          // Use the robust initialization function
          rooms[roomId] = initializeRoom(roomId, rooms[roomId]);
          rooms[roomId].externalTimer = matchRows[0].match_time;

          // Join the socket to the room
          socket.join(roomId);

          // Store room ID on socket for cleanup
          socket.roomId = roomId;

          // Confirm room creation to client
          socket.emit("roomCreated", { roomId });

          // console.log(`Room created: ${roomId}`, rooms[roomId]);
        } catch (error) {
          console.error("Error checking room:", error);
          socket.emit("roomError", { error: "Server error creating room" });
        }
      } catch (error) {
        console.error("Error in createRoom:", error);
        socket.emit("error", "Server error");
      }
    });

    /**
     * 2. JOIN ROOM
     */
    socket.on("joinRoom", async ({ roomId, user_id }) => {
      // console.log("Join Room Request:", { roomId, user_id });
      // console.log("Before Join - Existing Room State:", rooms[roomId]);

      try {
        const connection = await db.pool.getConnection();

        // 1. Get match info from DB
        const [matchRows] = await connection.execute(
          `SELECT * FROM matches WHERE match_id = ?`,
          [roomId]
        );
        if (matchRows[0].match_status !== "waiting") {
          return socket.emit("error", "Match is already started or completed");
        }
        if (matchRows.length === 0) {
          connection.release();
          return socket.emit("error", "Match not found in database");
        }
        const match = matchRows[0];
        // console.log('Fetched match data:', match);

        // 2. Get this player's record from DB
        const [playerRows] = await connection.execute(
          `SELECT * FROM players WHERE match_id = ? AND user_id = ? LIMIT 1`,
          [roomId, user_id]
        );
        connection.release();
        if (playerRows.length === 0) {
          return socket.emit("error", "Player not registered for this match");
        }
        const dbPlayer = playerRows[0];
        const { name, color } = dbPlayer;

        // 3. Ensure room exists in memory with robust initialization
        let room = (rooms[roomId] = initializeRoom(roomId, rooms[roomId]));

        // Store match data - This is important!
        room.match = match;

        // console.log('Match data assigned to room:', room.match);

        // 4. Check max player limit by match type
        const type = match.match_type?.toLowerCase();
        const maxPlayers = type === "two" ? 2 : type === "three" ? 3 : 4;
        if (Object.keys(room.players).length >= maxPlayers) {
          return socket.emit("error", "Room is full");
        }

        // 5. Check if this color is already taken
        if (room.players[color]) {
          return socket.emit("error", "Player already exist");
        }

        // 6. Prevent joining after start
        if (room.started) {
          return socket.emit("error", "Game already started");
        }

        // 7. Store for disconnect cleanup
        socket.roomId = roomId;
        socket.playerColor = color;

        // 8. Add to in-memory room
        room.players[color] = {
          id: socket.id,
          user_id,
          name,
          color,
          diceVal: null,
          isRolling: false,
          hasRolled: false,
          inactiveTurns:0,
          consecutiveSixes: 0,
          isMyTurn: false,
          tokens: [1, 1, 1, 1],
          score: 0,
        };

        // Ensure turnOrder is populated uniquely
        if (!room.turnOrder.includes(color)) {
          room.turnOrder.push(color);
        }

        // 9. Join socket.io room
        socket.join(roomId);

        // console.log('After Join - Updated Room State:', rooms[roomId]);
        // console.log('Updated Turn Order:', room.turnOrder);
        // console.log('Match data before broadcast:', room.match);

        // 10. Broadcast using your custom format
        io.to(roomId).emit("roomUpdated", {
          roomId,
          match: room.match || {}, // Use room.match which we just set above
          players: Object.values(room.players),
        });
      } catch (err) {
        console.error("Error in joinRoom:", err);
        socket.emit("error", "Server error while joining room");
      }
    });

    /**
     * 3. START GAME
     * Begin the game when ready
     */
    socket.on("startGame", async (roomId) => {
      try {
        // Validate room exists
        const room = rooms[roomId];

        if (!room) return socket.emit("error", "Room not found");

        // Query the DB for match type
        const [matchRows] = await db.pool.query(
          "SELECT match_type, match_status FROM matches WHERE match_id = ? LIMIT 1",
          [roomId]
        );

        if (matchRows.length === 0) {
          return socket.emit("error", "Match not found in DB");
        }

        if (matchRows[0].match_status !== "waiting") {
          return socket.emit("error", "Match is already started or completed");
        }

        const matchType = matchRows[0].match_type?.toLowerCase();
        const minPlayers =
          matchType === "two" ? 2 : matchType === "three" ? 3 : 4;

        // Check minimum player count
        if (room.turnOrder.length < minPlayers) {
          return socket.emit(
            "error",
            `At least ${minPlayers} players required to start a ${matchType}-player game`
          );
        }

        // Update match_status in DB
        await db.pool.query(
          "UPDATE matches SET match_status = ? WHERE match_id = ?",
          ["started", roomId]
        );

        // Mark game as started in memory
        rooms[roomId].started = true;

        // Start the game timer when the game starts
        if (rooms[roomId].started === true) {
          startGameTimer(roomId);
        }

        // console.log('Start Game - Room State:', rooms[roomId]);

        // Notify all players and start the game
        broadcastRoom(roomId);
        io.to(roomId).emit("gameStarted");

        // Start turn timer
        startTurnTimer(roomId);
      } catch (error) {
        console.error("Error starting game:", error);
        socket.emit("error", "Server error starting game");
      }
    });

    /**
     * Starts a timer for the current player's turn
     * When timer expires, the turn is automatically skipped
     */
    function startTurnTimer(roomId) {
  // Clear any existing timer first
  clearTurnTimer(roomId);

  const room = rooms[roomId];
  if (!room || !room.started || room.turnOrder.length === 0) return;

  // Check if only one player left - end game by elimination
  if (room.turnOrder.length === 1) {
    endGame(roomId, "elimination");
    return;
  }

  // Skip disconnected players automatically
  let attempts = 0;
  while (attempts < room.turnOrder.length) {
    const activeColor = room.turnOrder[room.currentTurnIdx];
    const activePlayer = room.players[activeColor];

    if (activePlayer && !activePlayer.isDisconnected) {
      break; // Found an active player
    }

    // Skip to next player
    room.currentTurnIdx = (room.currentTurnIdx + 1) % room.turnOrder.length;
    attempts++;
  }

  // If we've checked all players and none are active
  if (attempts >= room.turnOrder.length) {
    // console.log("All players disconnected, ending game");
    endGame(roomId, "all_disconnected");
    return;
  }

  const activeColor = room.turnOrder[room.currentTurnIdx];
  const activePlayer = room.players[activeColor];

  if (!activePlayer || activePlayer.isDisconnected) {
    // All players are disconnected
    // console.log("All players disconnected, ending game");
    endGame(roomId, "all_disconnected");
    return;
  }

  // Reset only active player's hasRolled flag
  activePlayer.hasRolled = false;
  activePlayer.isRolling = false;
  activePlayer.diceVal = null;

  io.to(roomId).emit("turnStarted", activeColor);

  // Set timeout for the current turn
  room.turnTimer = setTimeout(() => {
    // Check if room still exists and game is still active
    const currentRoom = rooms[roomId];
    if (!currentRoom || !currentRoom.started) return;

    // Check if only one player left before processing turn
    if (currentRoom.turnOrder.length === 1) {
      endGame(roomId, "elimination");
      return;
    }

    const currentActiveColor = currentRoom.turnOrder[currentRoom.currentTurnIdx];
    
    // Skip to next player when time runs out
    currentRoom.currentTurnIdx = (currentRoom.currentTurnIdx + 1) % currentRoom.turnOrder.length;

    // Notify all players that the turn was skipped
    io.to(roomId).emit("turnSkipped", currentRoom.turnOrder[currentRoom.currentTurnIdx]);
    
    // Increment inactive turns for the player who timed out
    if (currentRoom.players[currentActiveColor]) {
      currentRoom.players[currentActiveColor].inactiveTurns++;

      if (currentRoom.players[currentActiveColor].inactiveTurns >= 4) {
        // Remove player due to inactivity - removePlayerFromGame will handle starting next turn
        removePlayerFromGame(roomId, currentActiveColor, "timeout");
        return; // Don't call startTurnTimer again, removePlayerFromGame will handle it
      }
    }

    // Continue to next turn only if player wasn't removed and game is still active
    if (currentRoom.started && currentRoom.turnOrder.length > 1) {
      startTurnTimer(roomId);
    }
  }, TURN_TIMEOUT); 
}


    /**
     * Clears the turn timer for a room if it exists
     */
    function clearTurnTimer(roomId) {
      const room = rooms[roomId];
      if (room && room.turnTimer) {
        clearTimeout(room.turnTimer);
        room.turnTimer = null;
      }
    }

    /**
     * 5. MOVE TOKEN
     * Player moves a token based on dice roll
     */

    socket.on("moveToken", ({ roomId, color, tokenIdx }) => {
      try {
        // console.log("moveToken received:", roomId, color, tokenIdx);
        // Validate room and game state
        const room = rooms[roomId];
        if (!room || !room.started) {
          // console.log("Room not found or game not started");
          return socket.emit("error", "Game not started or room not found");
        }

        // Ensure it's this player's turn
        const turnColor = room.turnOrder[room.currentTurnIdx];
        if (color !== turnColor) {
          // console.log(`Not player's turn. Current turn: ${turnColor}, Player: ${color}`);
          return socket.emit("error", "Not your turn");
        }

        const player = room.players[color];
        if (!player) {
          // console.log(`Player ${color} not found in room`);
          return socket.emit("error", "Player not found");
        }
        player.inactiveTurns = 0
        // Debug logging
        // console.log(`Player data:`, {
        //   color,
        //   diceVal: player.diceVal,
        //   tokenIdx,
        //   currentPos: player.tokens ? player.tokens[tokenIdx] : undefined,
        //   playerRolling: player.isRolling
        // });

        const steps = player.diceVal; // Get dice value from player object

        if (!steps) {
          // console.log(`No dice value for player ${color}`);
          return socket.emit("error", "You must roll the dice first");
        }

        // Make sure tokenIdx is valid
        if (
          tokenIdx === undefined ||
          tokenIdx < 0 ||
          tokenIdx >= player.tokens.length
        ) {
          // console.log(`Invalid token index: ${tokenIdx}`);
          return socket.emit("error", "Invalid token selected");
        }

        let pos = player.tokens[tokenIdx];
        // console.log(`Current position: ${pos}, Steps: ${steps}`);
        io.to(roomId).emit("tokenSelected",
          {tokenPos:pos}
        )

        // Calculate new position
        let newPos = pos + steps;

        // Prevent moving beyond path end (PATH_LENGTH)
        if (newPos > PATH_LENGTH) {
          // console.log(`Move beyond path end: ${newPos} > ${PATH_LENGTH}`);
          return socket.emit("error", "Cannot move beyond finish line");
        }
        // Flag to track if player gets an extra turn
        let getsExtraTurn = false;

        // Update score and position if actually moving
        if (newPos !== pos) {
          // console.log(`Moving token ${tokenIdx} from ${pos} to ${newPos}`);

          // Calculate score based on steps taken
          player.score += steps;

          // Update token position
          player.tokens[tokenIdx] = newPos;

          // If landed on a safe zone, emit an event
          if (isSafeZone(newPos)) {
            // console.log(`Token landed on safe zone at position ${newPos}`);
            io.to(roomId).emit("safeZone", {
              color: color,
              tokenIdx: tokenIdx,
              position: newPos,
            });
          } else {
            // Check for "cutting" other player's tokens (only if not in a safe zone)
            // Convert position to global board position based on player color
            const globalPosition = getGlobalPosition(color, newPos);

            for (const [otherColor, other] of Object.entries(room.players)) {
              if (otherColor === color) continue; // Skip current player

              // First, count how many tokens the opponent has at this position
              let opponentTokensAtPosition = 0;
              const opponentTokensIndices = [];

              for (let ti = 0; ti < other.tokens.length; ti++) {
                const otherPos = other.tokens[ti];
                // Skip tokens that are at starting position (1)
                if (otherPos <= 1) continue;

                // Convert the other player's position to global board position
                const otherGlobalPos = getGlobalPosition(otherColor, otherPos);

                if (otherGlobalPos === globalPosition) {
                  opponentTokensAtPosition++;
                  opponentTokensIndices.push(ti);
                }
              }

              // Can cut tokens ONLY if opponent has exactly one token at this position
              // If opponent has 2+ tokens, they form a safe group that cannot be cut
              if (opponentTokensAtPosition === 1) {
                // Get the index of the single token to cut
                const tokenToCut = opponentTokensIndices[0];
                // console.log(`Cutting ${otherColor}'s token ${tokenToCut} at global position ${globalPosition}`);

                // Track previous position for score calculation
                const prevPos = other.tokens[tokenToCut];

                // Send back to position 1 (starting point)
                other.tokens[tokenToCut] = 1;

                // Deduct score - the number of places lost
                if (prevPos > 1) {
                  other.score = Math.max(0, other.score - (prevPos - 1));
                }

                // Emit an event to notify about the cut
                io.to(roomId).emit("tokenCut", {
                  cutColor: otherColor,
                  cutTokenIdx: tokenToCut,
                  byColor: color,
                });

                // Give player an extra turn for cutting a token
                getsExtraTurn = true;
                io.to(roomId).emit("extraTurn", { color, reason: "cut" });
              } else if (opponentTokensAtPosition >= 2) {
                // Opponent has 2 or more tokens - they form a safe group and can't be cut
                // console.log(`${color}'s token will coexist with ${otherColor}'s safe group`);
              }
            }
          }

          // Check if token completed the full path (reached position 57)
          if (newPos === PATH_LENGTH) {
            console.log(
              `Player ${color}'s token ${tokenIdx} completed the full path!`
            );
            getsExtraTurn = true;
            io.to(roomId).emit("extraTurn", { color, reason: "complete" });
          }
        } else {
          // console.log(`No movement for token ${tokenIdx}, staying at ${pos}`);
        }

        // Reset dice value after move
        // console.log(`Resetting dice value for player ${color}`);
        player.diceVal = null;
        player.isRolling = false;

        // Check for win condition (all tokens have reached the end)
        const hasWon = player.tokens.every((t) => t === PATH_LENGTH);

        if (hasWon) {
          // console.log(`Player ${color} has won!`);
          endGame(roomId, "complete");
          return;
        }

        // Check if player gets another turn (rolled a 6, cut a token, or completed path)
    
    let shouldMoveTurn = true; // Flag to control turn progression

    // Check if player gets another turn (rolled a 6, cut a token, or completed path)
    if (steps === 6 || getsExtraTurn) {
      if (steps === 6) {
        player.consecutiveSixes = (player.consecutiveSixes || 0) + 1;
        
        if (player.consecutiveSixes === 2) {
        
          player.consecutiveSixes = 0;
          // Move to next player's turn as penalty
          shouldMoveTurn = true;
          
        } else {
          // Player gets another turn for rolling 6 
          shouldMoveTurn = false;
        }
      } else {
        // Player gets another turn for cutting or completing
        shouldMoveTurn = false;
      }
    } else {
      // Normal move - next player's turn
      player.consecutiveSixes = 0;
      shouldMoveTurn = true;
    }

    // Apply turn progression
    if (shouldMoveTurn) {
      room.currentTurnIdx = (room.currentTurnIdx + 1) % room.turnOrder.length;
    }

    // Reset player state for next action
    player.hasRolled = false;

  
        // Create a sanitized copy of the room data for broadcasting
        const safeRoomData = {
          players: Object.values(rooms[roomId].players)
            .filter((player) => !player.isDisconnected) // Only show connected players
            .map((player) => ({
              id: player.id,
              user_id: player.user_id,
              name: player.name,
              color: player.color,
              diceVal: player.diceVal,
              isRolling: player.isRolling,
              consecutiveSixes: player.consecutiveSixes,
              hasRolled: player.hasRolled,
              inactiveTurns: player.inactiveTurns,
              isMyTurn:
                player.color ===
                rooms[roomId].turnOrder[rooms[roomId].currentTurnIdx],
              tokens: [...player.tokens],
              score: player.score,
              isDisconnected: player.isDisconnected || false,
            })),
          currentTurn: rooms[roomId].turnOrder[rooms[roomId].currentTurnIdx],
          started: rooms[roomId].started,
          winner: rooms[roomId].winner,
          activePlayers: rooms[roomId].turnOrder.length,
        };

        // console.log(`Broadcasting Room ${roomId} - ${Object.keys(rooms[roomId].players).length} players, turn: ${safeRoomData.currentTurn}`);

        io.to(roomId).emit("roomUpdated", safeRoomData);

        // Start the turn timer for the next player
        startTurnTimer(roomId);
      } catch (error) {
        console.error("Error while moving token:", error);
        socket.emit("error", "Server error");
      }
    });

    /**
     * End the game and update player rankings in the database
     */
    async function endGame(roomId, winReason = "complete") {
      const room = rooms[roomId];
      if (!room || room.winner) return;

      // console.log(`Ending game in room ${roomId}. Reason: ${winReason}`);

      // Clear all timers first
      clearTurnTimer(roomId);
      if (room.timerInterval) {
        clearInterval(room.timerInterval);
        room.timerInterval = null;
      }

      // Get the actual number of players in this game
      const playerCount =
        Object.keys(room.players).length +
        Object.keys(room.disconnectedPlayers || {}).length;
      // console.log(`Game ending with ${playerCount} total players`);

      // Collect all players (active + disconnected)
      const allPlayers = [];

      // Add active players
      Object.values(room.players).forEach((player) => {
        allPlayers.push({
          ...player,
          isActive: true,
        });
      });

      // Add disconnected players
      Object.values(room.disconnectedPlayers || {}).forEach(
        (disconnectedData) => {
          allPlayers.push({
            ...disconnectedData.player,
            isActive: false,
          });
        }
      );

      // Sort players by ranking logic based on win reason
      let sortedPlayers = [];

      if (winReason === "complete") {
        // Normal completion - sort by score and completion status
        sortedPlayers = allPlayers.sort((a, b) => {
          const aCompleted =
            a.tokens && a.tokens.every((t) => t === PATH_LENGTH);
          const bCompleted =
            b.tokens && b.tokens.every((t) => t === PATH_LENGTH);

          if (aCompleted && !bCompleted) return -1;
          if (!aCompleted && bCompleted) return 1;

          return b.score - a.score;
        });
      } else if (winReason === "timer") {
        // Timer ended - sort by score only
        sortedPlayers = allPlayers.sort((a, b) => b.score - a.score);
      } else if (winReason === "elimination") {
        // One player left wins
        sortedPlayers = allPlayers.sort((a, b) => {
          if (a.isActive && !b.isActive) return -1;
          if (!a.isActive && b.isActive) return 1;
          return b.score - a.score;
        });
      } else if (winReason === "all_disconnected") {
        // All disconnected - sort by score
        sortedPlayers = allPlayers.sort((a, b) => b.score - a.score);
      }

      // Assign rankings
      const rankings = ["first", "second", "third", "fourth"];
      let winner = null;

      // Prepare database updates
      const playerUpdates = [];

      try {
        // Start database transaction
        const connection = await db.pool.getConnection();
        await connection.beginTransaction();

        try {
          // Update match status first
          await connection.execute(
            "UPDATE matches SET match_status = ? WHERE match_id = ?",
            ["completed", roomId]
          );

          // Update each player with their final ranking and reason
          for (let index = 0; index < sortedPlayers.length; index++) {
            const player = sortedPlayers[index];
            const rank = index < rankings.length ? rankings[index] : "fourth";

            if (index === 0) {
              winner = player.color;
              room.winner = player.color;
            }

            // Determine the reason for this specific player
            let playerReason = winReason;
            if (!player.isActive && winReason !== "all_disconnected") {
              playerReason = "disconnected";
            }

            await connection.execute(
              "UPDATE players SET score = ?, winner = ?, reason = ? WHERE match_id = ? AND user_id = ?",
              [player.score || 0, rank, playerReason, roomId, player.user_id]
            );

            playerUpdates.push({
              user_id: player.user_id,
              rank: rank,
              score: player.score || 0,
              reason: playerReason,
              color: player.color,
              name: player.name,
            });

            // console.log(`Updated player ${player.user_id} (${player.color}): rank=${rank}, score=${player.score}, reason=${playerReason}`);
          }

          // Commit transaction
          await connection.commit();
          // console.log(`Database updated successfully for room ${roomId}`);
        } catch (error) {
          // Rollback on error
          await connection.rollback();
          throw error;
        } finally {
          connection.release();
        }
      } catch (err) {
        console.error("Error updating game results:", err);
        // Continue with game end even if DB update fails
      }

      // Prepare player data for frontend
      const playersData = sortedPlayers.map((player, index) => ({
        id: player.user_id,
        name: player.name,
        score: player.score || 0,
        rank: index < rankings.length ? rankings[index] : "fourth",
        color: player.color,
        isActive: player.isActive,
      }));

      // Clear all disconnect timeouts
      Object.values(room.disconnectedPlayers || {}).forEach(
        (disconnectedData) => {
          if (disconnectedData.timeout) {
            clearTimeout(disconnectedData.timeout);
          }
        }
      );

      // Emit game results to all players
      io.to(roomId).emit("gameOver", {
        winner: winner,
        reason: winReason,
        players: playersData,
      });

      // console.log(`Game ended in room ${roomId}:`, {
      //   winner,
      //   reason: winReason,
      //   players: playersData
      // });

      // Schedule room cleanup
      setTimeout(() => cleanupRoom(roomId), 15000); // Clean up after 15 seconds
    }

    /**
     * Convert a player's position to the global board position
     */
    function getGlobalPosition(color, position) {
      // If position is 1 or less (home or not on board), it's not on the main track
      if (position <= 1) return -1;

      // If position is in the final stretch (home stretch), it's not on the main track
      if (position >= 52) return -1;

      // Each color starts at a different position on the board
      // Standard Ludo board has 52 total spaces (4 quadrants of 13 spaces each)
      const startingPositions = {
        red: 1, // Red starts at global position 1
        green: 14, // Green starts at global position 14
        yellow: 27, // Yellow starts at global position 27
        blue: 40, // Blue starts at global position 40
      };

      // Calculate the global position
      let globalPos = startingPositions[color] + position - 2;

      // Wrap around the board if needed (global board is 1-52)
      if (globalPos > 52) {
        globalPos = globalPos - 52;
      }

      return globalPos;
    }

    // Improved safe zone function - standard Ludo safe zones
    function isSafeZone(position) {
      // These are the standard safe positions in Ludo
      // Starting positions, star positions, and entry to home stretch
      const safePositions = [
        1, 9, 14, 22, 27, 35, 40, 48, 52, 53, 54, 55, 56, 57,
      ];

      return safePositions.includes(position);
    }

    socket.on("rollDice", ({ roomId }) => {
      try {
        // console.log('Roll Dice Request for Room:', roomId);

        const room = rooms[roomId];
        if (!room || !room.started) {
          // console.log("Room not found or game not started");
          return socket.emit("error", "Game not started or room not found");
        }

        const turnColor = room.turnOrder[room.currentTurnIdx];
        const player = room.players[turnColor];

        if (player.id !== socket.id) {
          // console.log(`Not player's turn. Current turn: ${turnColor}, Socket ID: ${socket.id}`);
          return socket.emit("error", "Not your turn");
        }

        if (player.hasRolled) {
          return socket.emit(
            "error",
            "You have already rolled the dice for this round"
          );
        }

        // Now safe to roll
       const dice = Math.floor(Math.random() * 6) + 1;

        // console.log(`Player ${turnColor} rolled ${dice}`);

        // Store result
        player.diceVal = dice;
        player.isRolling = true;
        player.hasRolled = true;

        // Emit to room
        io.to(roomId).emit("diceRolled", {
          dice,
          player: turnColor,
        });

        // Create a sanitized copy of the room data for broadcasting
        const safeRoomData = {
          players: Object.values(room.players).map((player) => ({
            id: player.id,
            user_id: player.user_id,
            name: player.name,
            color: player.color,
            diceVal: player.diceVal,
            isRolling: player.isRolling,
            hasRolled: player.hasRolled,
            isMyTurn: player.color === room.turnOrder[room.currentTurnIdx],
            tokens: [...player.tokens], // Create a copy of the array
            score: player.score,
          })),
          currentTurn: room.turnOrder[room.currentTurnIdx],
          started: room.started,
        };

        // Broadcast updated room state to all players
        io.to(roomId).emit("roomUpdated", safeRoomData);
      } catch (error) {
        console.error("Error in Roll dice:", error);
        socket.emit("error", "Server error");
      }
      // Don't start the turn timer yet - wait for the player to move
    });

    // Improved broadcastRoom function to avoid circular references
    function broadcastRoom(roomId) {
      if (!rooms[roomId]) return;

      // Create a sanitized copy of the room data
      const safeRoomData = {
        players: Object.values(rooms[roomId].players)
          .filter((player) => !player.isDisconnected) // Only show connected players
          .map((player) => ({
            id: player.id,
            user_id: player.user_id,
            name: player.name,
            color: player.color,
            diceVal: player.diceVal,
            isRolling: player.isRolling,
            hasRolled: player.hasRolled,
            inactiveTurns: player.inactiveTurns,
            consecutiveSixes: player.consecutiveSixes,
            isMyTurn:
              player.color ===
              rooms[roomId].turnOrder[rooms[roomId].currentTurnIdx],
            tokens: [...player.tokens],
            score: player.score,
            isDisconnected: player.isDisconnected || false,
          })),
        currentTurn: rooms[roomId].turnOrder[rooms[roomId].currentTurnIdx],
        started: rooms[roomId].started,
        winner: rooms[roomId].winner,
        activePlayers: rooms[roomId].turnOrder.length,
      };

      // console.log(`Broadcasting Room ${roomId} - ${Object.keys(rooms[roomId].players).length} players, turn: ${safeRoomData.currentTurn}`);

      io.to(roomId).emit("roomUpdated", safeRoomData);
    }

    /**
     * Start the game timer
     * Converts the room's externalTimer (in minutes) to seconds and starts a countdown
     */
    function startGameTimer(roomId) {
      const room = rooms[roomId];
      if (!room) return;

      // Don't restart if timer is already running
      if (room.externalTimer && room.timerInterval) return;

      // Convert externalTimer from minutes to seconds
      const timerMinutes = room.externalTimer || 5; // Default to 5 minutes if not set
      const totalSeconds = timerMinutes * 60;

      room.gameStartTime = Date.now();
      room.gameTimer = totalSeconds;

      // Format time as MM:SS for frontend display
      const formattedTime = formatTime(room.gameTimer);

      // Emit initial timer value
      io.to(roomId).emit("gameTimerUpdate", {
        seconds: room.gameTimer,
        totalSeconds: totalSeconds,
        displayTime: formattedTime,
      });

      // Start interval to count down and emit updates
      room.timerInterval = setInterval(() => {
        room.gameTimer--;

        // Format time as MM:SS for frontend display
        const formattedTime = formatTime(room.gameTimer);

        // Emit timer update every second
        io.to(roomId).emit("gameTimerUpdate", {
          seconds: room.gameTimer,
          totalSeconds: totalSeconds,
          displayTime: formattedTime,
        });

        if (room.gameTimer <= 0) {
          clearInterval(room.timerInterval);
          room.timerInterval = null;

          // End the game with "timer" reason - this will trigger endGame to rank players by score
          endGame(roomId, "timer");
        }
      }, 1000);
    }

    /**
     * Format seconds into MM:SS display format
     */
    function formatTime(totalSeconds) {
      const minutes = Math.floor(totalSeconds / 60);
      const seconds = totalSeconds % 60;
      return `${minutes}:${seconds < 10 ? "0" + seconds : seconds}`;
    }

    /**
     * Clean up a room and free resources
     */
    function cleanupRoom(roomId) {
      console.log(`Cleaning up room ${roomId}`);

      const room = rooms[roomId];
      if (!room) return;

      // Clear all timers
      if (room.externalTimer) {
        clearInterval(room.externalTimer);
      }

      if (room.turnInterval) {
        clearInterval(room.turnInterval);
      }

      if (room.turnTimer) clearTimeout(room.turnTimer);
      if (room.timerInterval) clearInterval(room.timerInterval);

      // Remove all sockets from the room
      io.socketsLeave(roomId);

      // Delete the room object
      delete rooms[roomId];

      console.log(`Room ${roomId} cleaned up successfully`);
    }

    // Disconnecciton  function

    async function removePlayerFromGame(
  roomId,
  playerColor,
  reason = "disconnect"
) {
  const room = rooms[roomId];
  if (!room) return;

  const player = room.players[playerColor];
  if (!player) return;

  try {
    // Get total number of players who started the game
    const totalPlayers = 
      Object.keys(room.players).length + 
      Object.keys(room.disconnectedPlayers || {}).length;

    // Count how many have already disconnected
    const alreadyDisconnected = Object.keys(room.disconnectedPlayers || {}).length;
   
    
    // Assign rank from the bottom up (last places first)
    let finalRank = "fourth"; // default
    const remainingAfterThis = totalPlayers - alreadyDisconnected - 1;
    
    if (totalPlayers === 2) {
      finalRank = "second"; // In 2-player game, disconnected gets 2nd
    } else if (totalPlayers === 3) {
      if (alreadyDisconnected === 0) finalRank = "third";  // First to disconnect gets 3rd
      else finalRank = "second"; // Second to disconnect gets 2nd  
    } else if (totalPlayers === 4) {
      if (alreadyDisconnected === 0) finalRank = "fourth";      // First disconnect gets 4th
      else if (alreadyDisconnected === 1) finalRank = "third";  // Second disconnect gets 3rd
      else finalRank = "second";                                // Third disconnect gets 2nd
    }

    // **IMPORTANT: Don't update database here for disconnected players**
    // Let endGame handle all final ranking to avoid conflicts
    
    // Move to disconnected players (but don't update DB yet)
    if (!room.disconnectedPlayers) {
      room.disconnectedPlayers = {};
    }
    
    room.disconnectedPlayers[playerColor] = {
      player: player,
      timeout: null,
      finalRank: finalRank,
      disconnected: true
    };

    // Remove from active players and turn order
    delete room.players[playerColor];
    const playerIndex = room.turnOrder.indexOf(playerColor);
    if (playerIndex !== -1) {
      room.turnOrder.splice(playerIndex, 1);
      
      if (room.currentTurnIdx >= room.turnOrder.length) {
        room.currentTurnIdx = 0;
      } else if (room.currentTurnIdx > playerIndex) {
        room.currentTurnIdx--;
      }
    }

    // Check win conditions
    if (room.turnOrder.length === 1 && room.started) {
      endGame(roomId, "elimination");
      return;
    } else if (room.turnOrder.length === 0) {
      await db.pool.query(
        "UPDATE matches SET match_status = ? WHERE match_id = ?",
        ["completed", roomId]
      );
      endGame(roomId, "all_disconnected");
      return;
    }

    broadcastRoom(roomId);
    
    if (room.started && room.turnOrder.length > 0) {
      startTurnTimer(roomId);
    }
  } catch (error) {
    console.error("Error removing player from game:", error);
  }
}

    // Disconnection
    socket.on("disconnect", async () => {
      console.log(`Socket disconnected: ${socket.id}`);
      try {
        const roomId = socket.roomId;
        const playerColor = socket.playerColor;

        if (!roomId || !playerColor) return;

        const room = rooms[roomId];
        if (!room) return;

        const player = room.players[playerColor];
        if (!player) return;

        // console.log(`Player ${playerColor} disconnected from room ${roomId}`);

        if (!room.started) {
          // Game hasn't started - remove player immediately
          const playerIndex = room.turnOrder.indexOf(playerColor);
          if (playerIndex !== -1) {
            room.turnOrder.splice(playerIndex, 1);
          }
          delete room.players[playerColor];

          // console.log(`Player ${playerColor} removed from waiting room`);
          broadcastRoom(roomId);

          return;
        }

        // Reconnection
        socket.on("reconnectToRoom", async ({ roomId, user_id }) => {
          try {
            const room = rooms[roomId];
            if (!room) {
              return socket.emit("error", "Room no longer exists");
            }

            // Find the player's color from disconnected players or active players
            let playerColor = null;
            let player = null;

            // Check disconnected players first
            for (const [color, disconnectedData] of Object.entries(
              room.disconnectedPlayers
            )) {
              if (disconnectedData.player.user_id === user_id) {
                playerColor = color;
                player = disconnectedData.player;
                break;
              }
            }

            // Check active players
            if (!playerColor) {
              for (const [color, activePlayer] of Object.entries(
                room.players
              )) {
                if (activePlayer.user_id === user_id) {
                  playerColor = color;
                  player = activePlayer;
                  break;
                }
              }
            }

            if (!playerColor || !player) {
              return socket.emit("error", "Player not found in this room");
            }

            // Cancel disconnect timeout if exists
            if (room.disconnectedPlayers[playerColor]) {
              clearTimeout(room.disconnectedPlayers[playerColor].timeout);
              delete room.disconnectedPlayers[playerColor];
            }

            // Update socket information
            socket.roomId = roomId;
            socket.playerColor = playerColor;
            socket.join(roomId);

            // Update player data
            player.id = socket.id;
            player.isDisconnected = false;
            room.players[playerColor] = player;

            // Emit reconnection success
            socket.emit("reconnectedSuccessfully", {
              roomId,
              playerColor,
              roomState: {
                players: Object.values(room.players),
                currentTurn: room.turnOrder[room.currentTurnIdx],
                started: room.started,
              },
            });

            // Notify other players
            io.to(roomId).emit("playerReconnected", { color: playerColor });

            broadcastRoom(roomId);
          } catch (error) {
            console.error("Error in reconnection:", error);
            socket.emit("error", "Server error");
          }
        });

        // Game has started - give grace period for reconnection
        room.disconnectedPlayers[playerColor] = {
          player: player,
          disconnectTime: Date.now(),
          timeout: setTimeout(async () => {
            await removePlayerFromGame(roomId, playerColor, "timeout");
          }, DISCONNECT_TIMEOUT),
        };

        // Mark player as disconnected but keep in game temporarily
        player.isDisconnected = true;

        // If it's this player's turn, skip to next player
        if (room.turnOrder[room.currentTurnIdx] === playerColor) {
          // Clear turn timer
          clearTurnTimer(roomId);

          // Move to next player
          room.currentTurnIdx =
            (room.currentTurnIdx + 1) % room.turnOrder.length;

          // Start timer for next player
          startTurnTimer(roomId);
        }

        // Broadcast player disconnection
        io.to(roomId).emit("playerDisconnected", {
          color: playerColor,
          gracePeriod: DISCONNECT_TIMEOUT / 1000,
        });

        broadcastRoom(roomId);
      } catch (error) {
        console.error("Error in createRoom:", error);
        socket.emit("error", "Server error");
      }
    });
  });
};
