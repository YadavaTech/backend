require('dotenv').config();

module.exports = (req, res, next) => {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.split(' ')[1]; // Extract token after "Bearer"

  if (token === process.env.API_SECRET_TOKEN) {
    return next(); 
  }

  return res.status(403).json({ message: 'Forbidden: Invalid API token' });
};
