// Global error handlers - MUST be at the very top
process.on('uncaughtException', (error) => {
  console.error('💥 Uncaught Exception:', error);
  console.error('Stack:', error.stack);
  process.exit(1);
  //gracefully shutdown
 
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection at:', promise);
  console.error('Reason:', reason);
  process.exit(1);
  
  // Convert unhandled rejections to exceptions
});

// Add this for graceful shutdown
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const socketHandler = require('./controllers/socketController');
const { checkConnection } = require('./db/connection');
const routerController = require('./controllers/routesController');
const apiAuth = require('./middleware/apiAuth');
const cors = require('cors');

const app = express();

// Enhanced CORS configuration
app.use(cors({ 
  origin: process.env.CLIENT_URL || 'http://localhost:5173', 
  credentials: true,
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '2mb' })); 
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

//request timeout middleware
app.use((req, res, next) => {
  req.setTimeout(20000, () => {
    console.error('Request timeout for:', req.url);
    res.status(408).json({ error: 'Request timeout' });
  });
  next();
});

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: process.env.CLIENT_URL || 'http://localhost:5173',  
    methods: ['GET', 'POST'],
    credentials: true
  },
  transports: ['websocket', 'polling']
});


// Must be at bottom of middleware stack
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    console.error('💥 Malformed JSON:', err.message);
    return res.status(400).json({ message: 'Invalid JSON format in request body.' });
  }

  next(err); // pass to final error handler if needed
});

// Add global error handler middleware for Express
app.use((error, req, res, next) => {
  console.error('Express Error:', error);
  res.status(500).json({ 
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? error.message : 'Something went wrong'
  });
});


// API Routes with enhanced error handling
app.post('/api/create-game',apiAuth, async (req, res,next) => {
  try {
    
    await routerController.joinOrCreateGame(req, res,next);
  } catch (error) {
    console.error('Error in create-game:', error);
    res.status(500).json({ error: 'Failed to create/join game' });
  }
});

app.get('/api/game/:match_id',apiAuth, async (req, res,next) => {
  try {
    await routerController.getMatchById(req, res,next);
  } catch (error) {
    console.error('Error in get match:', error);
    res.status(500).json({ error: 'Failed to fetch match' });
  }
});

app.get('/api/player/:user_id',apiAuth, async (req, res,next) => {
  try {
    await routerController.getPlayerMatches(req, res,next);
  } catch (error) {
    console.error('Error in get player matches:', error);
    res.status(500).json({ error: 'Failed to fetch player matches' });
  }
});

// Health check endpoint
app.get('api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Attach socket logic with error wrapper
try {
  socketHandler(io);
  console.log('✅ Socket handler attached successfully');
} catch (error) {
  console.error('❌ Failed to attach socket handler:', error);
  process.exit(1);
}

// Store server reference for graceful shutdown
let serverInstance;

// Enhanced server startup
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || 'localhost';

async function startServer() {
  try {
    // Test database connection first
    console.log('🔄 Testing database connection...');
    await checkConnection();
    console.log('✅ Database connection successful');

    // Start server
    serverInstance = server.listen(PORT, HOST, () => {
      console.log(`🚀 Server running on http://${HOST}:${PORT}`);
      console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log(`🕒 Started at: ${new Date().toISOString()}`);
    });

    // Handle server errors
    serverInstance.on('error', (error) => {
      if (error.code === 'EADDRINUSE') {
        console.error(`❌ Port ${PORT} is already in use`);
        process.exit(1);
      } else {
        console.error('❌ Server error:', error);
      }
    });

  } catch (error) {
    console.error('❌ Failed to start server:', error.message);
    console.error('Stack:', error.stack);
    process.exit(1);
  }
}

// Graceful shutdown function
async function gracefulShutdown(signal) {
  console.log(`\n🛑 Received ${signal}. Starting graceful shutdown...`);

  try {
    // Close server
    if (serverInstance) {
      console.log('🔄 Closing HTTP server...');
      await new Promise((resolve) => {
        serverInstance.close(resolve);
      });
      console.log('✅ HTTP server closed');
    }

    // Close socket.io
    if (io) {
      console.log('🔄 Closing Socket.IO server...');
      io.close();
      console.log('✅ Socket.IO server closed');
    }

    // Close database connections
    try {
      const db = require('./db/connection');
      if (db.pool) {
        console.log('🔄 Closing database connections...');
        await db.pool.end();
        console.log('✅ Database connections closed');
      }
    } catch (dbError) {
      console.error('❌ Error closing database:', dbError);
    }

    console.log('✅ Graceful shutdown completed');
    process.exit(0);

  } catch (error) {
    console.error('❌ Error during graceful shutdown:', error);
    process.exit(1);
  }
}

// Add uncaught exception handler specifically for async operations
process.on('warning', (warning) => {
  console.warn('⚠️ Node.js Warning:', warning.name, warning.message);
});

// Start the server
startServer();